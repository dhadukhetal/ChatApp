﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatApi.DataServices
{
    public static class Connection
    {
        public static string DataBaseName = "";
        public static string Constr = "";
    }
}
