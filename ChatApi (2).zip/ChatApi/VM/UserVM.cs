﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ChatApi.VM
{
    public class UserVM
    {
        public int OperatorID { get; set; }
    }
}