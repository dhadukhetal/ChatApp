﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ChatApi.vmModels
{
    public class GeneralVM
    {
        public string _parameterType { get; set; }
    }
}